#pragma once
#include <SDL2/SDL.h>
#include <vector>
#include "alglin.h"
#include "iluminacao.h"
#include "imagem.h"
#include "objeto.h"
#include "observador.h"
using std::vector;

class Cenario{
  public:
    vector<Objeto*> Objetos;
    vector<LuzPontual*> Luzes;
    LuzAmbiente* LA;

    // Retorna o objeto visto pelo observador. Se o observador não ver nada, retorna alguma coisa (ver essa questão)
    int escolheObj(Ponto* P0, Vetor* dr);
    Cor* iluminarFinal(Ponto* Pi, Objeto* escolhido, Vetor* dr);
    void desenhar(SDL_Renderer *renderer, Observador* Obs, float d);
    bool intersecLuz(Objeto* Obj, Cenario* cenario, Ponto* Pi, LuzPontual* Lp);
    Intensidade* iluminarIndiv(Objeto* obj, Ponto* Pi, Cenario* cenario, Vetor* dr, LuzPontual* Lp);
};