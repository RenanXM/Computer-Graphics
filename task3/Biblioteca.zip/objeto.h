#pragma once
#include "alglin.h"
#include "iluminacao.h"

class Objeto
{
public:
  Intensidade* Ke;
  Intensidade* Kd;
  Intensidade* Ka;
  float m; // Shininess

  // Retorna o t do ponto mais próximo do objeto em relação a P0 considerando dr
  virtual float intersecObj(Ponto* P0, Vetor* dr);
  virtual Vetor* calcN(Ponto* Pi);
  virtual bool sombraPropria(Ponto* Pi, LuzPontual* Lp, Vetor* L, float t);

  Vetor* calcL(Ponto* Pi, Ponto* Pf);
  Vetor* calcR(Vetor* n, Vetor* l);
  Vetor* calcV(Vetor* dr);
};

class Esfera : public Objeto
{
public:
  float r;
  Ponto* c;
  Esfera();
  Esfera(float r, Ponto* c, Intensidade* Ke, Intensidade* Kd, Intensidade* Ka, float m);
  float intersecObj(Ponto* P0, Vetor* dr);
  Vetor* calcN(Ponto* Pi);
  bool sombraPropria(Ponto* Pi, LuzPontual* Lp, Vetor* L, float t);
};

class Plano : public Objeto
{
public:
  Ponto* Ppi;
  Vetor* npi;
  Plano();
  Plano(Ponto* Ppi, Vetor* npi, Intensidade* Ke, Intensidade* Kd, Intensidade* Ka, float m);
  float intersecObj(Ponto* P0, Vetor* dr);
  Vetor* calcN(Ponto* Pi);
  bool sombraPropria(Ponto* Pi, LuzPontual* Lp, Vetor* L, float t);
};