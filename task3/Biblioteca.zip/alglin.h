#pragma once

class Vetor
{
public:
  float x, y, z;
  Vetor();
  Vetor(float x, float y, float z);
};

class Ponto
{
public:
  float x, y, z;
  Ponto();
  Ponto(float x, float y, float z);
};


float prodEsc(Vetor* v1, Vetor* v2);
float Modulo(Vetor* v);
Vetor* subV(Vetor* v1, Vetor* v2);
Vetor* subP(Ponto* P1, Ponto* P2);
Vetor* addV(Vetor* v1, Vetor* v2);
Vetor* multEscV(Vetor* v1, float k);
Ponto* addPV(Ponto* p, Vetor* v);