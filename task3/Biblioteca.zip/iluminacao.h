#pragma once
#include "alglin.h"

class Cor
{
public:
  float r, g, b;
  Cor();
  Cor(float r, float g, float b);
};

class Intensidade
{
public:
  float r, g, b;
  Intensidade();
  Intensidade(float r, float g, float b);
};

class LuzPontual
{
public:
  Ponto* Pf;
  Intensidade* If;
  LuzPontual();
  LuzPontual(Ponto* Pf, Intensidade* If);
};

class LuzAmbiente
{
public:
  Intensidade* Ia;
  LuzAmbiente();
  LuzAmbiente(Intensidade* Ia);
};

Intensidade* arroba(Intensidade* i1, Intensidade* i2);
Intensidade* escalarI(Intensidade* I, float k);
Intensidade* somaI(Intensidade* I1, Intensidade* I2);