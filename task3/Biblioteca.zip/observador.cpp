#include "observador.h"
#include "alglin.h"

Observador::Observador(){}

Observador::Observador(Ponto* P0){
  this->P0 = P0;
}