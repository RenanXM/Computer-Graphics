#include "alglin.h"
#include "iluminacao.h"
#include "objeto.h"
#include "math.h"
Vetor *Objeto::calcN(Ponto *Pi)
{
  return new Vetor(1, 1, 1);
}

float Objeto::intersecObj(Ponto *P0, Vetor *dr)
{
  return -4000;
}

bool Objeto::sombraPropria(Ponto *Pi, LuzPontual *Lp, Vetor *L, float t)
{
  return false;
}

Vetor *Objeto::calcL(Ponto *Pi, Ponto *Pf)
{
  return multEscV(subP(Pf, Pi), 1 / Modulo(subP(Pf, Pi)));
}

Vetor *Objeto::calcR(Vetor *n, Vetor *l)
{
  // Vetor *r = subV(multEscV(n, 2 * prodEsc(l, n)), l);
  // return multEscV(r, 1/Modulo(r));
  return subV(multEscV(n, 2 * prodEsc(l, n)), l);
}

Vetor *Objeto::calcV(Vetor *dr)
{
  return multEscV(dr, -1 / Modulo(dr));
}

Esfera::Esfera() {}

Esfera::Esfera(float r, Ponto *c, Intensidade *Ke, Intensidade *Kd, Intensidade *Ka, float m)
{
  this->r = r;
  this->c = c;
  this->Ke = Ke;
  this->Kd = Kd;
  this->Ka = Ka;
  this->m = m;
}

Vetor *Esfera::calcN(Ponto *Pi)
{
  // Vetor* n = multEscV(subP(Pi, this->c), 1 / this->r);
  // return multEscV(n, 1/Modulo(n));
  return multEscV(subP(Pi, this->c), 1 / this->r);
}

// Verifica se o raio, em teoria, bate na Esfera
float Esfera::intersecObj(Ponto *P0, Vetor *dr)
{
  Ponto *C = this->c;
  float radium = this->r;

  Vetor *w = subP(P0, C);
  float a = prodEsc(dr, dr);
  float b = 2 * prodEsc(w, dr);
  float c = prodEsc(w, w) - (radium * radium);

  float delta = (b * b) - (4 * a * c);
  if (delta < 0)
    return -1;

  float t1 = (-b - sqrt(delta)) / (2 * a);
  float t2 = (-b + sqrt(delta)) / (2 * a);

  if (t1 > 0)
    return t1;
  if (t2 > 0)
    return t2;
  return -1;
}

bool Esfera::sombraPropria(Ponto *Pi, LuzPontual *Lp, Vetor *l, float t)
{
  float t_correto = Modulo(subP(Lp->Pf, Pi));
  if (t > t_correto)
    return true;

  return false;
}

Plano::Plano() {}

Plano::Plano(Ponto *Ppi, Vetor *npi, Intensidade *Ke, Intensidade *Kd, Intensidade *Ka, float m)
{
  this->Ppi = Ppi;
  this->npi = npi;
  this->Ke = Ke;
  this->Kd = Kd;
  this->Ka = Ka;
  this->m = m;
}

// Verifica se o raio, em teoria, bate no Plano
float Plano::intersecObj(Ponto *P0, Vetor *dr)
{
  Vetor *w = subP(P0, this->Ppi);
  return -(prodEsc(w, this->npi) / prodEsc(dr, this->npi));
}

Vetor *Plano::calcN(Ponto *Pi)
{
  return multEscV(this->npi, 1/Modulo(this->npi));
}

bool Plano::sombraPropria(Ponto *Pi, LuzPontual *Lp, Vetor *l, float t)
{
  return false;
}