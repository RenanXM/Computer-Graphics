#pragma once
#include "alglin.h"

class Observador
{
public:
  Ponto* P0;
  Observador();
  Observador(Ponto* P0);
};